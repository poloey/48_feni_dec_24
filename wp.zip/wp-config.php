<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'uph43cli_feni');

/** MySQL database username */
define('DB_USER', 'uph43cli_sumon');

/** MySQL database password */
define('DB_PASSWORD', 'topuph43.?');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ']}2K_3siL9`:8Z]A4&q4sqLdC|sKF<,].<.oauLhlQ:_Pb)~9/rJ;BG)mu!9G[Q+');
define('SECURE_AUTH_KEY',  '2f2lnCJ&IQh@.+XaFr9TkN?&TwDu*2D`xA?ZhhDHCNEgx!w^NJaOj>IGVFy2%&[G');
define('LOGGED_IN_KEY',    'p@m+bNCTEHHISP?T_YWrg2c^mSR1W4&g6<@~X?gk>mW#,8Xje]^Ml_+)o/Lrvmno');
define('NONCE_KEY',        'sft$(OF6iue8T~,[,sgXm.Iox+%wNTMl}.T>s6~<2a^GAYEXCx|NqW{mlooGK*hk');
define('AUTH_SALT',        'y&e4q]Ok2d`45[Hm5:19]UP%oCu`9j*b3`8ab#.LMo?/b%DS|BPU>rqUB!3F80KK');
define('SECURE_AUTH_SALT', '?ov59Q`K^ h5 LB@h_CVD025ea`__w]d-y@Ibkb::FT-WM$ ix4$_,o&2:FLdQW,');
define('LOGGED_IN_SALT',   'le^ZXpYnB}RWl>p6.82{2N+;[G<;onWE>Q~ywsh)J^ ^=$;1.CP6zA_F^%|W8b8^');
define('NONCE_SALT',       './?%:8[y:!>:.@/`#aCpwUX13wL%.~G$3R#V9}yn7<9ZRXRN^21#4QCB,O4ugMCH');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
